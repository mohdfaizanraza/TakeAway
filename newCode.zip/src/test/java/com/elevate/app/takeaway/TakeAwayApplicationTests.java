package com.elevate.app.takeaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TakeAwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
