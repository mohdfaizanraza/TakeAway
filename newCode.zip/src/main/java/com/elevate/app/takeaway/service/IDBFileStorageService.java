package com.elevate.app.takeaway.service;

public interface IDBFileStorageService {
    
}
