package com.elevate.app.takeaway.model;

import java.util.List;

public class ResponseModel {
    public List<Object> data;
    public List<Object> errors;
    public String message;
    public long id;
    public int responseCode;


}
